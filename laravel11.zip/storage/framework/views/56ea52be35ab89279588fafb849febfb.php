<header class="bg-gradient-to-r from-pink-300 via-red-200 to-orange-300 shadow-sm">
    <div class="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
      <h1 class="text-3xl font-bold tracking-tight text-gray-900"><?php echo e($slot); ?></h1>
    </div>
  </header><?php /**PATH C:\laragon\www\Budi\resources\views/components/header.blade.php ENDPATH**/ ?>